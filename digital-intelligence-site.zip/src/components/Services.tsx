import { GraduationCap, Home, Laptop, Check } from "lucide-react";
import { Reveal } from "./Reveal";
import { Button } from "@/components/ui/button";

const services = [
  {
    id: "renforcement",
    Icon: GraduationCap,
    badge: "Vacances scolaires",
    title: "Cours de renforcement",
    description:
      "Préparation CEP & BEPC. Mathématiques, Français, Sciences, Lecture. Groupes réduits ou individuel.",
    benefits: [
      "Programme adapté au niveau de l'élève",
      "Exercices corrigés et compositions blanches",
      "Suivi de progression hebdomadaire",
    ],
    audience: "Élèves du primaire & collège",
  },
  {
    id: "domicile",
    Icon: Home,
    badge: "Premium",
    title: "Enseignement à domicile",
    description:
      "Cours particuliers à domicile à Niamey pour élèves du primaire et du collège. Horaires flexibles, suivi personnalisé, rapports d'évolution pour les parents.",
    benefits: [
      "Soirs et week-ends disponibles",
      "Méthodes pédagogiques modernes",
      "Rapport mensuel aux parents",
    ],
    audience: "Parents soucieux d'un suivi rigoureux",
    featured: true,
  },
  {
    id: "digital",
    Icon: Laptop,
    badge: "Formation pro",
    title: "Formation digitale métier",
    description:
      "Initiation à l'informatique et aux outils numériques pour les jeunes : bureautique, Internet, premiers pas en programmation.",
    benefits: [
      "Découverte de l'ordinateur et d'Internet",
      "Bureautique : Word, Excel, présentations",
      "Premiers pas en programmation web",
    ],
    audience: "Élèves du primaire & collège curieux du numérique",
  },
];

export function Services() {
  return (
    <section id="services" className="relative py-24 sm:py-32 bg-muted/40">
      <div className="mx-auto max-w-6xl px-6">
        <Reveal>
          <div className="text-center mb-16">
            <p className="text-xs uppercase tracking-widest text-primary font-medium mb-3">
              Services éducatifs
            </p>
            <h2 className="text-3xl sm:text-5xl font-bold">
              Trois offres, <span className="gradient-text">une seule exigence</span>
            </h2>
            <p className="mt-4 max-w-2xl mx-auto text-muted-foreground">
              Une pédagogie moderne au service de votre réussite, à Niamey et en
              ligne.
            </p>
          </div>
        </Reveal>

        <div className="grid gap-6 md:grid-cols-3">
          {services.map((s, i) => (
            <Reveal key={s.id} delay={i * 120}>
              <article
                className={`relative h-full rounded-2xl border bg-card p-7 shadow-card hover-lift flex flex-col ${
                  s.featured
                    ? "border-primary/40 ring-1 ring-primary/20"
                    : "border-border"
                }`}
              >
                {s.featured && (
                  <span className="absolute -top-3 left-7 inline-flex items-center rounded-full gradient-bg px-3 py-1 text-xs font-medium text-primary-foreground shadow-elegant">
                    Recommandé
                  </span>
                )}

                <span className="inline-flex h-12 w-12 items-center justify-center rounded-xl bg-primary/10 text-primary">
                  <s.Icon className="size-5" />
                </span>

                <p className="mt-5 text-[11px] uppercase tracking-widest font-medium text-muted-foreground">
                  {s.badge}
                </p>
                <h3 className="mt-1 text-xl font-semibold">{s.title}</h3>
                <p className="mt-2 text-sm text-muted-foreground leading-relaxed">
                  {s.description}
                </p>

                <ul className="mt-5 space-y-2.5">
                  {s.benefits.map((b) => (
                    <li key={b} className="flex items-start gap-2.5 text-sm">
                      <Check className="size-4 mt-0.5 text-primary shrink-0" />
                      <span>{b}</span>
                    </li>
                  ))}
                </ul>

                <div className="mt-6 pt-5 border-t border-border text-xs text-muted-foreground">
                  Pour : {s.audience}
                </div>

                <Button
                  asChild
                  className={`mt-5 w-full min-h-11 ${
                    s.featured ? "gradient-bg text-primary-foreground" : ""
                  }`}
                  variant={s.featured ? "default" : "outline"}
                >
                  <a href={`#contact?service=${s.id}`}>S'inscrire</a>
                </Button>
              </article>
            </Reveal>
          ))}
        </div>
      </div>
    </section>
  );
}
