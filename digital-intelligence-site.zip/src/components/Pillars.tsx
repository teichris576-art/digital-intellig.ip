import { Code2, LineChart, Newspaper } from "lucide-react";
import { Reveal } from "./Reveal";

const pillars = [
  {
    Icon: Code2,
    title: "Informatique & Programmation",
    description:
      "Sites web, applications, interfaces sur mesure. React, TypeScript, design systems et outils modernes.",
    skills: ["Web Design", "Front-end", "UI / UX", "Intégration"],
  },
  {
    Icon: LineChart,
    title: "Finance & Comptabilité",
    description:
      "Master en cours. Analyse financière, lecture de bilans, indicateurs et structuration de la donnée.",
    skills: ["Analyse", "Reporting", "Tableaux de bord"],
  },
  {
    Icon: Newspaper,
    title: "Veille & Actualité Pro",
    description:
      "Toujours à jour des évolutions tech et économiques. Une expertise vivante, jamais figée.",
    skills: ["Tech", "Économie", "Pédagogie"],
  },
];

export function Pillars() {
  return (
    <section id="expertise" className="relative py-24 sm:py-32 bg-muted/40">
      <div className="mx-auto max-w-6xl px-6">
        <Reveal>
          <div className="text-center mb-16">
            <p className="text-xs uppercase tracking-widest text-primary font-medium mb-3">
              Expertise
            </p>
            <h2 className="text-3xl sm:text-5xl font-bold">
              Trois piliers, <span className="gradient-text">une vision</span>
            </h2>
          </div>
        </Reveal>

        <div className="grid gap-6 md:grid-cols-3">
          {pillars.map((p, i) => (
            <Reveal key={p.title} delay={i * 120}>
              <article className="h-full rounded-2xl border border-border bg-card p-7 shadow-card hover-lift">
                <span className="inline-flex h-12 w-12 items-center justify-center rounded-xl gradient-bg text-primary-foreground shadow-elegant">
                  <p.Icon className="size-5" />
                </span>
                <h3 className="mt-5 text-lg font-semibold">{p.title}</h3>
                <p className="mt-2 text-sm text-muted-foreground leading-relaxed">
                  {p.description}
                </p>
                <ul className="mt-5 flex flex-wrap gap-2">
                  {p.skills.map((s) => (
                    <li
                      key={s}
                      className="rounded-full border border-border bg-background px-2.5 py-1 text-xs text-muted-foreground"
                    >
                      {s}
                    </li>
                  ))}
                </ul>
              </article>
            </Reveal>
          ))}
        </div>
      </div>
    </section>
  );
}
