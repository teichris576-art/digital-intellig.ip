import { ArrowRight, Sparkles } from "lucide-react";
import { Button } from "@/components/ui/button";
import { LogoDI } from "./LogoDI";

export function Hero() {
  return (
    <section
      id="top"
      className="relative isolate overflow-hidden hero-bg pt-32 pb-24 sm:pt-40 sm:pb-32"
    >
      {/* Subtle grid backdrop */}
      <div
        className="pointer-events-none absolute inset-0 -z-10 opacity-[0.18]"
        style={{
          backgroundImage:
            "linear-gradient(to right, color-mix(in oklab, var(--primary) 18%, transparent) 1px, transparent 1px), linear-gradient(to bottom, color-mix(in oklab, var(--primary) 18%, transparent) 1px, transparent 1px)",
          backgroundSize: "56px 56px",
          maskImage:
            "radial-gradient(ellipse at 50% 0%, black 30%, transparent 75%)",
        }}
      />

      <div className="mx-auto max-w-5xl px-6 text-center">
        <div className="animate-fade-in flex justify-center mb-8">
          <LogoDI size={72} className="shadow-glow rounded-2xl" />
        </div>

        <div
          className="animate-fade-in inline-flex items-center gap-2 rounded-full border border-border bg-background/60 px-3 py-1.5 text-xs font-medium text-muted-foreground backdrop-blur"
          style={{ animationDelay: "120ms", animationFillMode: "both" }}
        >
          <Sparkles className="size-3.5 text-accent" />
          <span className="uppercase tracking-wider">Bienvenue</span>
        </div>

        <h1
          className="animate-fade-in mt-6 text-4xl sm:text-6xl lg:text-7xl font-bold leading-[1.05]"
          style={{ animationDelay: "240ms", animationFillMode: "both" }}
        >
          <span className="gradient-text">Digital Intelligence</span>
        </h1>

        <p
          className="animate-fade-in mx-auto mt-6 max-w-2xl text-base sm:text-lg text-muted-foreground leading-relaxed"
          style={{ animationDelay: "360ms", animationFillMode: "both" }}
        >
          Mohamed Yoan — développeur web et pédagogue à Niamey. Je conçois des
          expériences numériques épurées et j'accompagne les élèves du primaire
          et du collège vers la réussite scolaire.
        </p>

        <div
          className="animate-fade-in mt-10 flex flex-col sm:flex-row items-center justify-center gap-3"
          style={{ animationDelay: "480ms", animationFillMode: "both" }}
        >
          <Button asChild size="lg" className="gradient-bg text-primary-foreground shadow-elegant min-h-11">
            <a href="#services">
              Découvrir mes services
              <ArrowRight className="ml-1.5 size-4" />
            </a>
          </Button>
          <Button asChild size="lg" variant="outline" className="min-h-11">
            <a href="#parcours">Voir mon parcours</a>
          </Button>
        </div>

        <div
          className="animate-fade-in mt-16 flex items-center justify-center gap-8 text-xs uppercase tracking-widest text-muted-foreground"
          style={{ animationDelay: "600ms", animationFillMode: "both" }}
        >
          <span>Niamey · Niger</span>
          <span className="h-1 w-1 rounded-full bg-muted-foreground/40" />
          <span>Web · Pédagogie</span>
          <span className="hidden sm:inline h-1 w-1 rounded-full bg-muted-foreground/40" />
          <span className="hidden sm:inline">5+ ans</span>
        </div>
      </div>
    </section>
  );
}
