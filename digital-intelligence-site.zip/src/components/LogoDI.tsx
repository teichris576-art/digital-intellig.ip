type LogoDIProps = {
  className?: string;
  size?: number;
};

export function LogoDI({ className, size = 36 }: LogoDIProps) {
  return (
    <svg
      width={size}
      height={size}
      viewBox="0 0 48 48"
      fill="none"
      xmlns="http://www.w3.org/2000/svg"
      className={className}
      aria-hidden="true"
    >
      <defs>
        <linearGradient id="di-grad" x1="0" y1="0" x2="48" y2="48" gradientUnits="userSpaceOnUse">
          <stop offset="0%" stopColor="oklch(0.52 0.08 195)" />
          <stop offset="100%" stopColor="oklch(0.7 0.13 230)" />
        </linearGradient>
      </defs>
      <rect x="2" y="2" width="44" height="44" rx="12" fill="url(#di-grad)" />
      <path
        d="M14 14h7.5c4.6 0 8 3.4 8 8s-3.4 8-8 8H14V14zm4 4v8h3.5c2.2 0 3.8-1.6 3.8-4s-1.6-4-3.8-4H18z"
        fill="white"
      />
      <rect x="32" y="14" width="3" height="16" rx="1.5" fill="white" />
      <circle cx="33.5" cy="34" r="1.6" fill="oklch(0.82 0.16 85)" />
    </svg>
  );
}
