import { useState } from "react";
import { useMutation } from "@tanstack/react-query";
import { useServerFn } from "@tanstack/react-start";
import { toast } from "sonner";
import { Mail, MapPin, MessageCircle, Phone, Send } from "lucide-react";
import { Input } from "@/components/ui/input";
import { Textarea } from "@/components/ui/textarea";
import { Label } from "@/components/ui/label";
import { Button } from "@/components/ui/button";
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from "@/components/ui/select";
import { Reveal } from "./Reveal";
import { submitContactMessage } from "@/lib/contact.functions";

export function Contact() {
  const submit = useServerFn(submitContactMessage);
  const [form, setForm] = useState({
    name: "",
    email: "",
    phone: "",
    service: "",
    message: "",
  });

  const mutation = useMutation({
    mutationFn: (data: typeof form) => submit({ data }),
    onSuccess: () => {
      toast.success("Message envoyé !", {
        description: "Je vous réponds rapidement.",
      });
      setForm({ name: "", email: "", phone: "", service: "", message: "" });
    },
    onError: (err: Error) => {
      toast.error("Erreur", { description: err.message });
    },
  });

  return (
    <section id="contact" className="relative py-24 sm:py-32">
      <div className="mx-auto max-w-6xl px-6">
        <div className="grid gap-12 lg:grid-cols-2 lg:gap-16">
          {/* Left: info */}
          <Reveal>
            <p className="text-xs uppercase tracking-widest text-primary font-medium mb-3">
              Contact
            </p>
            <h2 className="text-3xl sm:text-5xl font-bold">
              Parlons de <span className="gradient-text">votre projet</span>
            </h2>
            <p className="mt-4 text-muted-foreground max-w-md">
              Un site web à concevoir, un enfant à accompagner, une formation à
              suivre ? Écrivez-moi, réponse rapide garantie.
            </p>

            <ul className="mt-10 space-y-5">
              <li className="flex items-start gap-4">
                <span className="flex h-11 w-11 items-center justify-center rounded-xl bg-primary/10 text-primary shrink-0">
                  <MapPin className="size-5" />
                </span>
                <div>
                  <p className="font-medium">Niamey, Niger</p>
                  <p className="text-sm text-muted-foreground">
                    Interventions à domicile & à distance
                  </p>
                </div>
              </li>
              <li className="flex items-start gap-4">
                <span className="flex h-11 w-11 items-center justify-center rounded-xl bg-primary/10 text-primary shrink-0">
                  <MessageCircle className="size-5" />
                </span>
                <div>
                  <p className="font-medium">Disponibilité</p>
                  <p className="text-sm text-muted-foreground">
                    Vacances scolaires & périodes scolaires (soirs / week-ends)
                  </p>
                </div>
              </li>
              <li className="flex items-start gap-4">
                <span className="flex h-11 w-11 items-center justify-center rounded-xl bg-accent/15 text-accent shrink-0">
                  <Mail className="size-5" />
                </span>
                <div>
                  <p className="font-medium">Email</p>
                  <a
                    href="mailto:Adelinetei8@gmail.com"
                    className="text-sm text-muted-foreground hover:text-foreground transition-colors break-all"
                  >
                    Adelinetei8@gmail.com
                  </a>
                </div>
              </li>
              <li className="flex items-start gap-4">
                <span className="flex h-11 w-11 items-center justify-center rounded-xl bg-primary/10 text-primary shrink-0">
                  <Phone className="size-5" />
                </span>
                <div>
                  <p className="font-medium">Téléphone / WhatsApp</p>
                  <div className="flex flex-wrap items-center gap-x-3 gap-y-1 text-sm text-muted-foreground">
                    <a
                      href="tel:+22777979602"
                      className="hover:text-foreground transition-colors"
                    >
                      +227 77 97 96 02
                    </a>
                    <span className="text-muted-foreground/40">·</span>
                    <a
                      href="https://wa.me/22777979602"
                      target="_blank"
                      rel="noopener noreferrer"
                      className="hover:text-foreground transition-colors"
                    >
                      WhatsApp
                    </a>
                  </div>
                </div>
              </li>
            </ul>
          </Reveal>

          {/* Right: form */}
          <Reveal delay={150}>
            <form
              onSubmit={(e) => {
                e.preventDefault();
                mutation.mutate(form);
              }}
              className="rounded-2xl border border-border bg-card p-6 sm:p-8 shadow-card"
            >
              <div className="grid gap-4 sm:grid-cols-2">
                <div className="space-y-2">
                  <Label htmlFor="name">Nom complet</Label>
                  <Input
                    id="name"
                    required
                    maxLength={100}
                    value={form.name}
                    onChange={(e) => setForm({ ...form, name: e.target.value })}
                    placeholder="Votre nom"
                  />
                </div>
                <div className="space-y-2">
                  <Label htmlFor="email">Email</Label>
                  <Input
                    id="email"
                    type="email"
                    required
                    maxLength={255}
                    value={form.email}
                    onChange={(e) => setForm({ ...form, email: e.target.value })}
                    placeholder="vous@exemple.com"
                  />
                </div>
              </div>

              <div className="grid gap-4 sm:grid-cols-2 mt-4">
                <div className="space-y-2">
                  <Label htmlFor="phone">Téléphone (optionnel)</Label>
                  <Input
                    id="phone"
                    type="tel"
                    maxLength={40}
                    value={form.phone}
                    onChange={(e) => setForm({ ...form, phone: e.target.value })}
                    placeholder="+227 ..."
                  />
                </div>
                <div className="space-y-2">
                  <Label htmlFor="service">Sujet</Label>
                  <Select
                    value={form.service}
                    onValueChange={(v) => setForm({ ...form, service: v })}
                  >
                    <SelectTrigger id="service">
                      <SelectValue placeholder="Choisir un sujet" />
                    </SelectTrigger>
                    <SelectContent>
                      <SelectItem value="web">Création de site web</SelectItem>
                      <SelectItem value="renforcement">Cours de renforcement</SelectItem>
                      <SelectItem value="domicile">Enseignement à domicile</SelectItem>
                      <SelectItem value="digital">Formation digitale</SelectItem>
                      <SelectItem value="autre">Autre</SelectItem>
                    </SelectContent>
                  </Select>
                </div>
              </div>

              <div className="space-y-2 mt-4">
                <Label htmlFor="message">Votre message</Label>
                <Textarea
                  id="message"
                  required
                  rows={5}
                  maxLength={2000}
                  value={form.message}
                  onChange={(e) => setForm({ ...form, message: e.target.value })}
                  placeholder="Décrivez votre besoin en quelques lignes…"
                />
              </div>

              <Button
                type="submit"
                size="lg"
                disabled={mutation.isPending}
                className="mt-6 w-full gradient-bg text-primary-foreground min-h-11"
              >
                {mutation.isPending ? (
                  "Envoi en cours…"
                ) : (
                  <>
                    Envoyer le message
                    <Send className="ml-1.5 size-4" />
                  </>
                )}
              </Button>
            </form>
          </Reveal>
        </div>
      </div>
    </section>
  );
}
