import { ArrowUpRight } from "lucide-react";
import { Reveal } from "./Reveal";

const projects = [
  {
    title: "Plateforme e-commerce",
    tag: "Web · 2024",
    description:
      "Boutique en ligne pour une enseigne locale, paiement intégré et tableau de bord administrateur.",
  },
  {
    title: "Tableau de bord analytique",
    tag: "SaaS · 2024",
    description:
      "Interface de visualisation de données pour une équipe finance, dashboards temps réel.",
  },
  {
    title: "Site institutionnel",
    tag: "Vitrine · 2023",
    description:
      "Identité numérique d'une organisation, design éditorial et SEO local.",
  },
  {
    title: "Application pédagogique",
    tag: "EdTech · 2023",
    description:
      "Outil de suivi scolaire pour parents et enseignants, mobile-first.",
  },
];

export function Portfolio() {
  return (
    <section id="portfolio" className="relative py-24 sm:py-32">
      <div className="mx-auto max-w-6xl px-6">
        <Reveal>
          <div className="flex items-end justify-between flex-wrap gap-4 mb-12">
            <div>
              <p className="text-xs uppercase tracking-widest text-primary font-medium mb-3">
                Réalisations
              </p>
              <h2 className="text-3xl sm:text-5xl font-bold">
                Quelques <span className="gradient-text">projets clés</span>
              </h2>
            </div>
            <p className="max-w-sm text-sm text-muted-foreground">
              Une sélection représentative de mes interventions front-end et
              produit. Plus de détails sur demande.
            </p>
          </div>
        </Reveal>

        <div className="grid gap-5 sm:grid-cols-2">
          {projects.map((p, i) => (
            <Reveal key={p.title} delay={i * 100}>
              <article className="group relative rounded-2xl border border-border bg-card p-7 shadow-card hover-lift overflow-hidden">
                <div
                  className="absolute -right-12 -top-12 h-40 w-40 rounded-full opacity-0 group-hover:opacity-100 transition-opacity"
                  style={{ background: "var(--gradient-primary)", filter: "blur(40px)" }}
                  aria-hidden="true"
                />
                <div className="relative">
                  <span className="text-xs uppercase tracking-widest text-muted-foreground">
                    {p.tag}
                  </span>
                  <h3 className="mt-2 text-xl font-semibold flex items-center gap-2">
                    {p.title}
                    <ArrowUpRight className="size-4 text-primary opacity-0 -translate-x-1 group-hover:opacity-100 group-hover:translate-x-0 transition" />
                  </h3>
                  <p className="mt-3 text-sm text-muted-foreground leading-relaxed">
                    {p.description}
                  </p>
                </div>
              </article>
            </Reveal>
          ))}
        </div>
      </div>
    </section>
  );
}
