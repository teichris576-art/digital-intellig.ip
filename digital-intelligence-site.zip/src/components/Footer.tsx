import { LogoDI } from "./LogoDI";

export function Footer() {
  return (
    <footer className="border-t border-border py-12">
      <div className="mx-auto max-w-6xl px-6 flex flex-col sm:flex-row items-center justify-between gap-6">
        <div className="flex items-center gap-2.5">
          <LogoDI size={28} />
          <span className="font-display font-semibold tracking-tight">
            Digital Intelligence
          </span>
        </div>

        <nav className="flex flex-wrap items-center justify-center gap-x-6 gap-y-2 text-sm text-muted-foreground">
          <a href="#parcours" className="hover:text-foreground transition-colors">Parcours</a>
          <a href="#services" className="hover:text-foreground transition-colors">Services</a>
          <a href="#contact" className="hover:text-foreground transition-colors">Contact</a>
          <a href="mailto:Adelinetei8@gmail.com" className="hover:text-foreground transition-colors">
            Adelinetei8@gmail.com
          </a>
          <a href="tel:+22777979602" className="hover:text-foreground transition-colors">
            +227 77 97 96 02
          </a>
        </nav>

        <p className="text-xs text-muted-foreground">
          © {new Date().getFullYear()} Mohamed Yoan · Niamey
        </p>
      </div>
    </footer>
  );
}
