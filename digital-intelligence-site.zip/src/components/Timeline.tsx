import { BookOpen, Trophy, GraduationCap, Rocket } from "lucide-react";
import { Reveal } from "./Reveal";

type Step = {
  year: string;
  title: string;
  place: string;
  description: string;
  Icon: typeof BookOpen;
  highlight?: boolean;
};

const steps: Step[] = [
  {
    year: "2018",
    title: "Baccalauréat",
    place: "Lycée — Niger",
    description:
      "Obtention du baccalauréat scientifique avec mention. Premier jalon d'un parcours académique exigeant.",
    Icon: BookOpen,
    highlight: true,
  },
  {
    year: "2019 – 2022",
    title: "Licence en Informatique",
    place: "Université",
    description:
      "Spécialisation en développement logiciel, algorithmique et bases de données. Projets web et mobile.",
    Icon: GraduationCap,
  },
  {
    year: "2021 – aujourd'hui",
    title: "Développeur Web Freelance",
    place: "Niamey · International",
    description:
      "Conception et développement d'interfaces sur mesure pour clients africains et internationaux. Stack moderne, focus produit.",
    Icon: Rocket,
  },
  {
    year: "2023 – aujourd'hui",
    title: "Master Finance & Comptabilité",
    place: "Formation continue",
    description:
      "Double expertise : technologie et finance. Vision transversale au service des projets numériques.",
    Icon: Trophy,
  },
];

export function Timeline() {
  return (
    <section id="parcours" className="relative py-24 sm:py-32">
      <div className="mx-auto max-w-5xl px-6">
        <Reveal>
          <div className="text-center mb-16">
            <p className="text-xs uppercase tracking-widest text-primary font-medium mb-3">
              Mon parcours
            </p>
            <h2 className="text-3xl sm:text-5xl font-bold">
              Un chemin <span className="gradient-text">tracé avec exigence</span>
            </h2>
            <p className="mt-4 max-w-2xl mx-auto text-muted-foreground">
              De la distinction au baccalauréat à la pratique professionnelle,
              chaque étape construit une expertise solide et plurielle.
            </p>
          </div>
        </Reveal>

        <ol className="relative">
          {/* center spine on desktop, left spine on mobile */}
          <div
            className="absolute top-0 bottom-0 left-6 md:left-1/2 w-px -translate-x-px"
            style={{
              backgroundImage:
                "linear-gradient(to bottom, transparent, color-mix(in oklab, var(--primary) 35%, transparent), transparent)",
            }}
            aria-hidden="true"
          />

          {steps.map((s, i) => {
            const left = i % 2 === 0;
            return (
              <li key={s.year} className="relative pl-16 md:pl-0 md:grid md:grid-cols-2 md:gap-12 pb-12 last:pb-0">
                {/* Node */}
                <div
                  className="absolute left-6 md:left-1/2 top-2 -translate-x-1/2 z-10"
                  aria-hidden="true"
                >
                  <span
                    className={`flex h-12 w-12 items-center justify-center rounded-full border ${
                      s.highlight
                        ? "border-accent/40 bg-accent/15 shadow-glow"
                        : "border-border bg-background"
                    }`}
                  >
                    <s.Icon className={`size-5 ${s.highlight ? "text-accent" : "text-primary"}`} />
                  </span>
                </div>

                <Reveal
                  delay={i * 120}
                  className={`md:col-start-${left ? 1 : 2} ${
                    left ? "md:text-right md:pr-12" : "md:text-left md:pl-12"
                  }`}
                >
                  <article className="rounded-2xl border border-border bg-card p-6 shadow-card hover-lift">
                    <div className="flex items-center gap-2 mb-2 text-xs uppercase tracking-widest font-medium text-muted-foreground">
                      <span>{s.year}</span>
                      {s.highlight && (
                        <span className="inline-flex items-center gap-1 rounded-full bg-accent/15 px-2 py-0.5 text-accent">
                          ★ Distinction
                        </span>
                      )}
                    </div>
                    <h3 className="text-xl font-semibold">{s.title}</h3>
                    <p className="text-sm text-muted-foreground mt-0.5">{s.place}</p>
                    <p className="mt-3 text-sm leading-relaxed text-foreground/80">
                      {s.description}
                    </p>
                  </article>
                </Reveal>
              </li>
            );
          })}
        </ol>
      </div>
    </section>
  );
}
