import { createFileRoute } from "@tanstack/react-router";
import { Nav } from "@/components/Nav";
import { Hero } from "@/components/Hero";
import { Timeline } from "@/components/Timeline";
import { Pillars } from "@/components/Pillars";
import { Portfolio } from "@/components/Portfolio";
import { Services } from "@/components/Services";
import { Contact } from "@/components/Contact";
import { Footer } from "@/components/Footer";

const SITE_TITLE =
  "Digital Intelligence — Mohamed Yoan · Développeur & Enseignant à Niamey";
const SITE_DESCRIPTION =
  "Mohamed Yoan, développeur web freelance et pédagogue à Niamey. Création de sites modernes, cours de renforcement et enseignement à domicile pour élèves du primaire et du collège.";

export const Route = createFileRoute("/")({
  head: () => ({
    meta: [
      { title: SITE_TITLE },
      { name: "description", content: SITE_DESCRIPTION },
      { property: "og:title", content: SITE_TITLE },
      { property: "og:description", content: SITE_DESCRIPTION },
      { property: "og:type", content: "website" },
      { property: "og:url", content: "/" },
      { property: "og:locale", content: "fr_FR" },
      { name: "twitter:card", content: "summary_large_image" },
      { name: "twitter:title", content: SITE_TITLE },
      { name: "twitter:description", content: SITE_DESCRIPTION },
    ],
    links: [{ rel: "canonical", href: "/" }],
    scripts: [
      {
        type: "application/ld+json",
        children: JSON.stringify({
          "@context": "https://schema.org",
          "@graph": [
            {
              "@type": "Person",
              name: "Mohamed Yoan",
              jobTitle: "Développeur web & Enseignant",
              email: "mailto:Adelinetei8@gmail.com",
              telephone: "+22777979602",
              address: {
                "@type": "PostalAddress",
                addressLocality: "Niamey",
                addressCountry: "NE",
              },
              knowsAbout: [
                "Développement Web",
                "Front-end",
                "Pédagogie",
                "Mathématiques",
                "Finance",
              ],
            },
            {
              "@type": "LocalBusiness",
              name: "Digital Intelligence",
              description: SITE_DESCRIPTION,
              areaServed: "Niamey, Niger",
              email: "Adelinetei8@gmail.com",
              telephone: "+22777979602",
              address: {
                "@type": "PostalAddress",
                addressLocality: "Niamey",
                addressCountry: "NE",
              },
            },
          ],
        }),
      },
    ],
  }),
  component: Index,
});

function Index() {
  return (
    <>
      <Nav />
      <Hero />
      <Timeline />
      <Pillars />
      <Portfolio />
      <Services />
      <Contact />
      <Footer />
    </>
  );
}
